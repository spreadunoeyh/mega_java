package ����;

import javax.swing.JFrame;

public class ��ǰ {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(500, 500);
		f.setVisible(true);
		// TODO Auto-generated method stub

	}

}
