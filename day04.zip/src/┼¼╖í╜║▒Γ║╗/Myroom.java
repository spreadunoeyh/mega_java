package Ŭ�����⺻;

public class Myroom {

	public static void main(String[] args) {
		Phone p1 = new Phone();
		p1.shape = "�׸�";
		p1.size = 9;
		
		p1.call();
		p1.katalk();
	
		Phone p2 = new Phone();
		p2.shape = "���簢��";
		p2.size = 11;
		p2.katalk();
		
		Dog d1 = new Dog();
		d1.color = "����";
		d1.age = 2;
		d1.move();		
		d1.bark();			
			
	}

}
